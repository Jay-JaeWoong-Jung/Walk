$(document).ready(function() {


	// 상단 메뉴 기능
	$('button.quick').click( function(e){
		var nav = $(this).next('ul');
		if( nav.is(':visible') ){
			$(this).text('메뉴 열기');
			$(this).css('background-color','#f5f5f5');
			nav.css('display', 'none');
		} else {
			$(this).text('메뉴 닫기');
			$(this).css('background-color','#e5e5e5');
			nav.css('display', 'block');
		}
	});

	
	// 레이어 팝업

	

	// 로그아웃 재확인
	$('.logout').click(function(){
		var isLogout = confirm("로그아웃합니다. 확인 버튼을 누르면 메인으로 돌아갑니다.");
		if( isLogout ){
			location.href = "logout.home?command=userLogout";
		}
	});



	// 페이지 위로 
	var btnTop = $('.btn_top');	
	btnTop.hide();
	$(window).scroll(function () {
		if ($(this).scrollTop() > 150) {
			btnTop.fadeIn();
		} else {
			btnTop.fadeOut();
		}
	});
    btnTop.click(function () {
		$('body,html').animate({
			scrollTop: 0
		}, 500);
		return false;
    });



});
--- 테이블 확인
SELECT * FROM member_list;

--- 테이블 완전 삭제
DROP TABLE member_list purge;


-- 회원 목록
create table member_list (
	num NUMBER not null primary key,
	email varchar2(200) not null,
	pwd varchar2(100) not null, 
	userLevel NUMBER not null,
	joinDate date not null,
		lastLoginDate date not null
);
	-- 0 : 탈퇴 회원
	-- 1 : 가입 회원
	-- 2 : 인증 회원
	-- 5 : 관리자

-- 시퀀스
create sequence member_seq
	start with 1
	increment BY 1
	maxvalue 100000
;

-- 임의 값 - 관리자
INSERT INTO member_list VALUES( member_seq.NEXTVAL, 'qwe', 'qwe','5',sysdate );


commit;